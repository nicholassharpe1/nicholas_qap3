import { useState, useEffect } from "react";
import "./App.css";
import "./components/BreedSelector";
import "./components/ImageGallery";
import BreedSelector from "./components/BreedSelector";
import ImageGallery from "./components/ImageGallery";
 
function App() {
  const [imageUrls, setImageUrls] = useState([]);
 
  const [Breed, setBreed] = useState("");
  const [ImageCount, setImageCount] = useState(1);
  const [Images, setImages] = useState([]);
  const HandleBreed = (SelectedBreed) => {
    setBreed(SelectedBreed);
  };
  const HandleImageCount = (Count) => {
    setImageCount(Count);
  };
  const HandleImages = (Images) => {
    setImages(Images);
  };
  return (
    <div className="App">
      <h1 className="title">Dog Photo Gallery Application</h1>
      <BreedSelector
        Breed={Breed}
        ImageCount={ImageCount}
        onBreedSelect={HandleBreed}
        onImageCount={HandleImageCount}
        HandleImages={HandleImages}
      />
      <ImageGallery images={Images} />
      <br/>
    </div>
  );
}
 
export default App;