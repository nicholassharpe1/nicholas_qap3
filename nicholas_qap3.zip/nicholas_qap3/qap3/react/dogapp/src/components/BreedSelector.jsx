import React from 'react'
import { useState, useEffect } from "react";
import "../BreedSelector.css";

export default function BreedSelector({Breed,ImageCount,onBreedSelect,onImageCount,HandleImages}) {
  const [Breeds, setBreeds] = useState([])
  useEffect(()=>{fetch("https://dog.ceo/api/breeds/list/all").then((response)=>response.json()).then((data)=>{setBreeds(Object.keys(data.message))}).catch((error)=>{console.log("Error",error)})},[])
  const HandleSubmit = (e) => {
    e.preventDefault()
    fetch(`https://dog.ceo/api/breed/${Breed}/images/random/${ImageCount}`)
    .then((response)=>response.json()).then((data)=>{HandleImages(data.message)}).catch((error)=>{console.log("Error",error)})
  }
  return (
    <div>
      <form onSubmit={HandleSubmit}>
        <label className='spacing'>
            Select Dog Type:
            <select value={Breed} onChange={(e) => onBreedSelect(e.target.value)} className='boxes1'>
                {Breeds.map((Breed) => (
                    <option key={Breed} value={Breed}>
                        {Breed}
                    </option>
                ))}
            </select>
        </label>
        <label className='spacing'>
            Number:
            <input
              type="number"
              className='boxes1'
              value={ImageCount}
              min="1"
              max="100"
              onChange={(e) => onImageCount(e.target.value)}
            />
        </label>
        <button type="submit" className='boxes2'>Fetch</button>
      </form>
    </div>
  )
}