import React from 'react';
import "../ImageGallery.css";

const ImageGallery = ({ images }) => {
  return (
    <div className="display">
      {images.map((imageUrl, index) => (
        <div className="components" key={index}>
          <img src={imageUrl} alt={`Image ${index}`} className="image" />
        </div>
      ))}
    </div>
  );
};

export default ImageGallery;